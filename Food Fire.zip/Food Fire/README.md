## Namaste React Course by Akshay Saini
# Chapter 09 - Optimizing our App


## Coding Assignment:
- Create your `custom hooks`.
- Try out `lazy and suspense`
- Make your `code clean`.


## Created a FoodFire App from scratch using React.js and Parcel.js 🚀 [Live Project App Link 😍](https://foodfire-chapter09.netlify.app/)